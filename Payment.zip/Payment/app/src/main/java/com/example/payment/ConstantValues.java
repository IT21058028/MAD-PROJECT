package com.example.payment;

public class ConstantValues
{
   public  String totalAmountIntent = "TOTAL_AMOUNT";
  public   String numOfTicketsIntent = "NUM_OF_SEATS";
  public   String seatNumbersIntent = "SEAT_NUMBERS";
  public   String ticketType = "TICKET_TYPE";
    public  String movieName = "MOVIE_NAME";
    public  String fullName = "FULL_NAME";
    public  String address = "ADDRESS";
    public  String email = "EMAIL";
}
