package com.example.payment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.android.material.textfield.TextInputEditText;

public class edit extends AppCompatActivity {

    TextInputEditText nameField, emailField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        nameField = findViewById(R.id.editFullName);
        emailField = findViewById(R.id.editEmail);


        nameField.setText(getIntent().getStringExtra("NAME"));
        emailField.setText(getIntent().getStringExtra("EMAIL"));
    }
}